^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package apriltag_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.1.1 (2019-10-07)
------------------
* Add support for tagStandard41h12 and tagStandard52h13 (`#63 <https://github.com/AprilRobotics/apriltag_ros/issues/63>`_, `#59 <https://github.com/AprilRobotics/apriltag_ros/issues/59>`_).
* Add gray image input support (`#58 <https://github.com/AprilRobotics/apriltag_ros/issues/58>`_).
* Contributors: Alexander Reimann, Moritz Zimmermann, Samuel Bachmann, Wolfgang Merkt

3.1.0 (2019-05-25)
------------------
* Prepare for release (3.1) and fix catkin_lint errors
* Upgrade to AprilTag 3, fix installation, and performance improvements (`#43 <https://github.com/AprilRobotics/apriltag_ros/issues/43>`_)
  Upgrade to AprilTag 3, fix installation, and performance improvements
* Rename package to apriltag_ros
  - Relates to https://github.com/AprilRobotics/apriltag_ros/issues/45
* Contributors: Wolfgang Merkt

1.0.0 (2018-05-14)
------------------
