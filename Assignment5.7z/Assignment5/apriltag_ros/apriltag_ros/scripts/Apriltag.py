#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from move_robot import MoveTurtlebot3
from apriltag_ros.msg import AprilTagDetectionArray
global center_img
global bridge_object    
bridge_object = CvBridge()

def apriltag_callback(tag):
       
    x =tag.detections[0].pose.pose.pose.position.x
    z =tag.detections[0].pose.pose.pose.position.z
    print("x",x)
    print("z",z)
    vel_msg = Twist()
    if z > 0.5 and x>0.01:
        vel_msg.linear.x = 0.2* z
        vel_msg.angular.z = -1.2 * x
    elif z > 0.5 and x<-0.01:
        print 'ahhh left'
        vel_msg.linear.x = 0.2 * z
        vel_msg.angular.z = (-1.2 * x)
    elif z > 0.5 :
        vel_msg.linear.x = 0.2 * z
       
    else:
       vel_msg.linear.x = 0
    
    pub.publish(vel_msg)
        
    	

rospy.init_node('apriltagfollower',anonymous=True)
aprilTag = rospy.Subscriber("/tag_detections",AprilTagDetectionArray, apriltag_callback)
pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)
vel_msg=Twist()
rospy.spin()

