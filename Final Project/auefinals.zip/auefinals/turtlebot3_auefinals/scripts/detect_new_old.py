#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import time
import math
import tf
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from sensor_msgs.msg import Image
from darknet_ros_msgs.msg import BoundingBoxes
from std_msgs.msg import Header
from move_robot import MoveTurtlebot3
from people_msgs.msg import PositionMeasurementArray
from people_msgs.msg import PositionMeasurement
from geometry_msgs.msg import Point
from geometry_msgs.msg import PoseArray
from nav_msgs.msg import Odometry

find = None
f = 0
d =0

leg_track_on = 0

class LineFollower(object):

    def __init__(self):
        print("subscribing to lidar")
        self.sub = rospy.Subscriber('/scan',LaserScan,self.lidar)
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw",Image,self.camera_callback)
        # self.image_sub = rospy.Subscriber("/camera/rgb/image_raw",Image,self.camera_callback)
        self.sub_darknet =rospy.Subscriber('/darknet_ros/bounding_boxes',BoundingBoxes,self.callback)
        self.bot_location = rospy.Subscriber("/odom",Odometry, self.bot_location)
        self.leg_tracking = rospy.Subscriber("/to_pose_array/leg_detector",PoseArray, self.legtracking_callback)
    def lidar(self,msg):
        # print("#####lidar#####")
        if f == 0:
            pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)
            front_range = 0
            left_range = 0
            right_range = 0
            #To calculate thedistance in the right
            c1=1;c2=1
            steer=0
            for i in range(285,359):
                if msg.ranges[i]<=2:
                    c1+=1
                    right_range = right_range + msg.ranges[i]

            	right_dist = right_range/c1#Finding average
                #print("right dist",right_dist)
            for j in range(1,75):
                if msg.ranges[j]<=2:
                    c2+=1

                    left_range = left_range + msg.ranges[j]
            	left_dist = left_range/c2 #Finding average
                #print("left dist",left_dist)
            vel_msg = Twist()

            steer = left_dist-right_dist


            if steer <=0.1 and steer >= -0.1 and msg.ranges[0]>0.5:
               # print 'left',left_dist
               # print 'right', right_dist
               vel_msg.linear.x = 0.2
               vel_msg.linear.y = 0
               vel_msg.linear.z = 0
               vel_msg.angular.x = 0
               vel_msg.angular.y = 0
               vel_msg.angular.z = 0
               pub.publish(vel_msg)

            else:
               # print'steer=', steer*1.8
               # print 'left',left_dist
               # print 'right', right_dist
               vel_msg.linear.x = 0.1 #To make the turns smooth
               vel_msg.linear.y = 0
               vel_msg.linear.z = 0
               vel_msg.angular.x = 0
               vel_msg.angular.y = 0
               vel_msg.angular.z = steer*1.8 # Proportional controller
               pub.publish(vel_msg)


    def bot_location(self,msg):
        global x_bot, y_bot, orientation_new

        quaternion = (msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w)
        euler = tf.transformations.euler_from_quaternion(quaternion)
        orientation_new = euler[2]

        x_bot = msg.pose.pose.position.x
        y_bot = msg.pose.pose.position.y

        return x_bot, y_bot, orientation_new

    def legtracking_callback(self,detect):
        global x_bot, y_bot, orientation_new, dist
        pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)
        vel_msg = Twist()
    	x = detect.poses[0].position.x
    	y = abs(detect.poses[0].position.y)
    	z = detect.poses[0].position.z
        if leg_track_on == 1:
            print(x,y,x_bot,y_bot)
            dist = math.sqrt((x-x_bot)**2 + (y-y_bot)**2)
            theta = math.atan2((y-y_bot),(x-x_bot))
            print(theta,orientation_new)
            theta_error = theta - orientation_new
            kp_linear = 0.15
            kp_angular = 0.25 #0.15
            rospy.loginfo("theta error is %f",theta_error)
            vel_msg.linear.x = 0
            vel_msg.angular.z = 0
            if dist > 0.3:
                rospy.loginfo(dist)
                vel_msg.linear.x = dist * kp_linear
                vel_msg.angular.z = theta_error * kp_angular
            pub.publish(vel_msg)

    def camera_callback(self,data):
        global leg_track_on
        if f==1 and leg_track_on == 0:
            # print("@@@@@@@@@camera callback@@@@@@@@@@@@")
            try:
                # We select bgr8 because its the OpneCV encoding by default
                self.moveTurtlebot3_object = MoveTurtlebot3()
                self.bridge_object = CvBridge()
                cv_image = self.bridge_object.imgmsg_to_cv2(data, desired_encoding="bgr8")

            except CvBridgeError as e:
                print(e)

            # We get image dimensions and crop the parts of the image we dont need
            height, width, channels = cv_image.shape
            crop_img = cv_image[(height)/2+160:(height)/2+160+120][1:width]

            # Convert from RGB to HSV
            hsv = cv2.cvtColor(crop_img, cv2.COLOR_BGR2HSV)

            # Define the Yellow Colour in HSV

            """
            To know which color to track in HSV use ColorZilla to get the color registered by the camera in BGR and convert to HSV.
            """

            # Threshold the HSV image to get only yellow colors
            lower_yellow = np.array([20,100,100])
            upper_yellow = np.array([50,255,255])
            mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
            print("mask!!!!!!!!!!!!!!!!")
            # Calculate centroid of the blob of binary image using ImageMoments
            m = cv2.moments(mask, False)

            try:
                cx, cy = m['m10']/m['m00'], m['m01']/m['m00']
            except ZeroDivisionError:
                cx, cy = height/2, width/2

            cv2.circle(mask,(int(cx), int(cy)), 10,(0,0,255),-1)
            cv2.imshow("MASK", mask)
            cv2.waitKey(1)

            """
    	    Enter controller here.
            """
            vel_msg = Twist()
            global find
            if find == 11:
                global d
                d = d+1
                start = rospy.get_time()
                start1 = start
                if d == 1:
                    while start1 <= start + 3.0:
                        # print('The start time:',start1)
                        vel_msg.linear.x = 0
                        vel_msg.angular.z = 0
                        self.moveTurtlebot3_object.move_robot(vel_msg)
                        start1 = rospy.get_time()
                else:
                    # twist_object =  Twist()
                    # print("EXIT")
                    vel_msg.linear.x = 0.09
                    error_value = cx - width/2
                    vel_msg.angular.z = -error_value/930
                    # rospy.loginfo(vel_msg.angular.z)
                    # rospy.loginfo("ANGULAR VALUE SENT===>"+str(vel_msg.angular.z))
                    # Make it start turning
                    self.moveTurtlebot3_object.move_robot(vel_msg)

            else:
                # print("EXIT")
                vel_msg.linear.x = 0.1
                error_value = cx - width/2
                vel_msg.angular.z = -error_value/930
                rospy.loginfo(vel_msg.angular.z)
                # rospy.loginfo("ANGULAR VALUE SENT===>"+str(vel_msg.angular.z))
                self.moveTurtlebot3_object.move_robot(vel_msg)

    def clean_up(self):
        self.vel_msg =  Twist()
        self.vel_msg.linear.x = 0
        self.vel_msg.angular.z = 0
        self.moveTurtlebot3_object.clean_class()
        cv2.destroyAllWindows()



    def callback(self,datar):
        # print("**********darknet_callback************")
        global leg_track_on
        person = 0

        for box in datar.bounding_boxes:
            global find
            find = box.id
            print('The Id is:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',find)
            if find == 0:
                print('The person value in the loop BEFORE:',person)
                person = person + 1
                print('The person value in the loop AFTER:',person)
                global f
                f = 1
                print("f",f)
            elif person == 1 and find == 0 and find == 74:
                global f
                f = 2
                # leg_track_on = 1
                print('THE LEG TRACK PART WENT')
                print("f",f)
        if person >=2 :
            # print('THE PERSON VALUE IN THE LOOP IS:'person)
            leg_track_on = 1
        rospy.loginfo("leg track %d",leg_track_on)
def main():
    # print("node initialising")
    rospy.init_node('line_following_node', anonymous=True)
    # print("object is created")
    line_follower_object = LineFollower()


    rate = rospy.Rate(5)
    ctrl_c = False
    def shutdownhook():
        # works better than the rospy.is_shut_down()
        line_follower_object.clean_up()
        rospy.loginfo("shutdown time!")
        ctrl_c = True

    rospy.on_shutdown(shutdownhook)

    while not ctrl_c:
        rate.sleep()

if __name__ == '__main__':
    main()
